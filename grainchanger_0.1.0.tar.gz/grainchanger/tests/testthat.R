library(testthat)
library(grainchanger)

test_check("grainchanger")
